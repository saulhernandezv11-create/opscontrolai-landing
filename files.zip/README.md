# OPS CONTROL AI Landing Page

Landing page for OPS CONTROL AI - AI-powered automation and infrastructure solutions.

## Features
- Operational chaos calculator
- Cloud infrastructure solutions
- AI automation services
- 24/7 monitoring
- Expert support

## Deployment
This site is deployed on Vercel at opscontrolai.com
